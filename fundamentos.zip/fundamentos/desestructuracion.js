const temperaturas = [ 25, 26, 25, 29, 93, 10]

const listaTemperaturas= () => {
    return [ 25, 26, 25, 29, 93, 10]
};

//const [, , t3, t4, , t6] = temperaturas
const [, , t3, t4, , t6] = listaTemperaturas()


console.log(t3,t4)